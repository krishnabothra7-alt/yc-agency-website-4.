import React, { useState } from 'react';
import { Navbar } from './components/Navbar.tsx';
import { Hero } from './components/Hero.tsx';
import { AboutIntro } from './components/AboutIntro.tsx';
import { ServicesSection } from './components/ServicesSection.tsx';
import { WhyYCSection } from './components/WhyYCSection.tsx';
import { ResultsSection } from './components/ResultsSection.tsx';
import { WorkClientsSection } from './components/WorkClientsSection.tsx';
import { FoundersSection } from './components/FoundersSection.tsx';
import { ContactCTA } from './components/ContactCTA.tsx';
import { Footer } from './components/Footer.tsx';
import { InquiryModal } from './components/InquiryModal.tsx';

export default function App() {
  const [modalOpen, setModalOpen] = useState(false);
  const [inquiryService, setInquiryService] = useState<string | undefined>(undefined);

  const handleOpenContact = (context?: string) => {
    setInquiryService(context);
    setModalOpen(true);
  };

  const handleSelectService = (serviceName: string) => {
    setInquiryService(`Inquiry about ${serviceName}`);
    setModalOpen(true);
  };

  return (
    <div className="min-h-screen bg-[#FAF9F6] text-[#0D0D0D] flex flex-col font-sans selection:bg-[#E11D74] selection:text-white">
      {/* Sticky Main Navigation */}
      <Navbar onOpenContact={() => handleOpenContact()} />

      {/* Main Content Sections */}
      <main className="flex-1">
        {/* Hero Section */}
        <Hero onOpenContact={() => handleOpenContact()} />

        {/* Services / What We Do */}
        <ServicesSection onSelectService={handleSelectService} />

        {/* Work / Brands We've Helped Grow */}
        <WorkClientsSection onOpenContact={handleOpenContact} />

        {/* About / Introduction */}
        <AboutIntro onOpenContact={() => handleOpenContact()} />

        {/* Why YC / Strategy With Purpose */}
        <WhyYCSection />

        {/* Results / The Numbers Speak */}
        <ResultsSection />

        {/* Founders / The People Behind YC */}
        <FoundersSection />

        {/* Final CTA / Ready To Grow */}
        <ContactCTA onOpenModal={() => handleOpenContact()} />
      </main>

      {/* Footer */}
      <Footer />

      {/* Global Project Brief Inquiry Modal */}
      <InquiryModal
        isOpen={modalOpen}
        onClose={() => setModalOpen(false)}
        initialService={inquiryService}
      />
    </div>
  );
}
