export interface ServiceItem {
  id: string;
  number: string;
  title: string;
  description: string;
  platforms: string[];
  deliverables?: string[];
}

export interface MetricItem {
  value: string;
  numericValue: number;
  suffix: string;
  decimals?: number;
  label: string;
  subtext?: string;
}

export interface ClientItem {
  name: string;
  category: 'Jewellery & Luxury' | 'Fashion & Apparel' | 'Food & Hospitality' | 'Lifestyle & Retail' | 'Education & Enterprise';
}

export const AGENCY_INFO = {
  name: 'YC',
  tagline: 'BUILDING AUTHORITY IN THE DIGITAL AGE',
  positioning: 'Specializing in Meta and LinkedIn marketing to help businesses build a strong social media presence, connect with the right audience and grow through strategic content and marketing.',
  email: 'ycagencyinfo@gmail.com',
  founders: [
    {
      name: 'YASHVEE BAID',
      role: 'FOUNDER',
      focus: 'Instagram, Facebook, WhatsApp & LinkedIn Strategy',
      bio: 'Yashvee leads Instagram, Facebook, WhatsApp and LinkedIn strategy and management, helping clients build a strong brand presence and connect with the right audience.',
      phone: '+91 99897 98548',
      telHref: 'tel:+919989798548',
      whatsappHref: 'https://wa.me/919989798548?text=Hello%20Yashvee,%20I%20would%20like%20to%20discuss%20social%20media%20marketing%20with%20YC.',
    },
    {
      name: 'CHETNA BOTHRA',
      role: 'FOUNDER',
      focus: 'Instagram Ad Creative & Strategy',
      bio: 'Chetna leads Instagram ad creative and strategy, crafting visuals and campaigns that convert.',
      phone: '+91 95813 14751',
      telHref: 'tel:+919581314751',
      whatsappHref: 'https://wa.me/919581314751?text=Hello%20Chetna,%20I%20would%20like%20to%20discuss%20ad%20creative%20and%20campaigns%20with%20YC.',
    },
  ],
  platforms: [
    { name: 'Instagram', href: 'https://instagram.com' },
    { name: 'Facebook', href: 'https://facebook.com' },
    { name: 'WhatsApp', href: 'https://wa.me/919581314751' },
    { name: 'LinkedIn', href: 'https://linkedin.com' },
    { name: 'YouTube', href: 'https://youtube.com' },
  ],
};

export const SERVICES: ServiceItem[] = [
  {
    id: '01',
    number: '01',
    title: 'META BRANDING',
    description: 'Instagram account set-up, profile optimization, bio writing and profile picture selection.',
    platforms: ['Instagram', 'Facebook'],
    deliverables: [
      'Account structure audit & positioning',
      'High-converting bio & link tree architecture',
      'Highlights iconography & visual curation',
      'Profile image & cover art standard'
    ],
  },
  {
    id: '02',
    number: '02',
    title: 'CONTENT CREATION',
    description: 'High-quality images, videos and other content to showcase your brand or products.',
    platforms: ['Instagram', 'Facebook', 'LinkedIn'],
    deliverables: [
      'Short-form vertical video & Reels direction',
      'High-fidelity graphic carousels & stills',
      'Product showcase visual narratives',
      'Editorial brand aesthetic governance'
    ],
  },
  {
    id: '03',
    number: '03',
    title: 'CONTENT SCHEDULING & PUBLISHING',
    description: 'Planning and scheduling content in advance for a consistent posting rhythm.',
    platforms: ['Meta Suite', 'LinkedIn'],
    deliverables: [
      'Monthly editorial content calendars',
      'Peak audience time slot calibration',
      'Cross-platform distribution syncing',
      'Zero-downtime queue maintenance'
    ],
  },
  {
    id: '04',
    number: '04',
    title: 'ANALYTICS & REPORTING',
    description: 'Tracking engagement, follower growth and reach, with detailed performance reports.',
    platforms: ['Meta Insights', 'LinkedIn Analytics'],
    deliverables: [
      'Monthly executive review dossiers',
      'Audience retention & demographic cohorts',
      'Post-by-post conversion attribution',
      'Strategic next-month tactical recommendations'
    ],
  },
  {
    id: '05',
    number: '05',
    title: 'META AUTOMATION',
    description: 'Simple automation set-up for hassle-free, consistent Instagram activity.',
    platforms: ['Instagram DM', 'WhatsApp Business'],
    deliverables: [
      'Automated DM lead capture funnels',
      'Instant inquiry response sequences',
      'Keyword-triggered story reply flows',
      'WhatsApp catalog & quick reply routing'
    ],
  },
  {
    id: '06',
    number: '06',
    title: 'COPYWRITING',
    description: 'SEO-friendly copy written to sell, not just to fill space.',
    platforms: ['Instagram', 'LinkedIn', 'Facebook'],
    deliverables: [
      'Hook-driven opening copy frameworks',
      'Search-optimized caption keyword tags',
      'Audience-aligned brand tone of voice',
      'Direct, frictionless calls to action'
    ],
  },
  {
    id: '07',
    number: '07',
    title: 'CUSTOMER TESTIMONIALS',
    description: 'Building a proper, organized testimonial bank for social proof.',
    platforms: ['Social Highlights', 'Ad Creatives'],
    deliverables: [
      'Systematic customer quote acquisition',
      'Video testimonial format curation',
      'High-impact social proof carousels',
      'Evergreen social proof highlight vaults'
    ],
  },
  {
    id: '08',
    number: '08',
    title: 'META ADS',
    description: 'Instagram and Facebook ad campaigns, considered once your page has established organic growth.',
    platforms: ['Meta Ads Manager'],
    deliverables: [
      'Full-funnel campaign architecture',
      'Creative variant testing (A/B)',
      'Lookalike & retargeting audience setup',
      'ROAS and inquiry cost optimization'
    ],
  },
  {
    id: '09',
    number: '09',
    title: 'PHOTOSHOOT & VIDEOGRAPHY',
    description: 'Two professional photoshoots a month, including videography, to keep content fresh.',
    platforms: ['On-Location', 'Studio Production'],
    deliverables: [
      'Two production shoots per calendar month',
      'High-resolution raw & edited photography',
      'Native vertical video captures for Reels',
      'Art direction, styling & shot-list curation'
    ],
  },
  {
    id: '10',
    number: '10',
    title: 'LINKEDIN MANAGEMENT & ADS',
    description: 'Page management plus sponsored campaigns built for B2B lead generation.',
    platforms: ['LinkedIn Company Page', 'Campaign Manager'],
    deliverables: [
      'Executive founder thought leadership ghostwriting',
      'Company page organic growth strategy',
      'Sponsored InMail & single image ads',
      'Decision-maker B2B lead generation'
    ],
  },
];

export const WHY_YC = [
  {
    number: '01',
    title: 'EXPERTISE',
    description: 'Our team consists of highly skilled professionals with extensive experience in Meta and LinkedIn Management, ensuring that your brand receives the best possible service.',
    highlight: 'Meta & LinkedIn Specialists',
  },
  {
    number: '02',
    title: 'RESULTS-ORIENTED',
    description: 'Our focus is on delivering measurable results and helping your business grow through effective Instagram marketing strategies.',
    highlight: 'Growth Driven & Quantifiable',
  },
  {
    number: '03',
    title: 'TRANSPARENCY',
    description: 'We maintain open and transparent communication with our clients, providing regular updates and reports to keep you informed of our progress.',
    highlight: 'Direct Founder Communication',
  },
  {
    number: '04',
    title: 'TAILORED STRATEGY WITH CREATIVITY',
    description: 'We offer tailored solutions to meet your unique business needs, ensuring maximum results and ROI. We pride ourselves on our ability to think outside the box and create engaging content that resonates with your target audience.',
    highlight: 'Uniquely Crafted For Your Niche',
  },
];

export const PRIMARY_METRICS: MetricItem[] = [
  {
    value: '52.8M+',
    numericValue: 52.8,
    suffix: 'M+',
    decimals: 1,
    label: 'TOTAL VIEWS',
    subtext: 'Across Meta & organic video distributions',
  },
  {
    value: '18.6M+',
    numericValue: 18.6,
    suffix: 'M+',
    decimals: 1,
    label: 'ACCOUNTS REACHED',
    subtext: 'Unique accounts exposed to client brands',
  },
  {
    value: '5.4M+',
    numericValue: 5.4,
    suffix: 'M+',
    decimals: 1,
    label: 'TOTAL ENGAGEMENTS',
    subtext: 'High-intent likes, comments, shares & saves',
  },
  {
    value: '99.7%',
    numericValue: 99.7,
    suffix: '%',
    decimals: 1,
    label: 'REACH FROM NON-FOLLOWERS',
    subtext: 'Algorithmic discovery & organic breakout',
  },
];

export const ADDITIONAL_METRICS: MetricItem[] = [
  {
    value: '104.3M+',
    numericValue: 104.3,
    suffix: 'M+',
    decimals: 1,
    label: 'CONTENT IMPRESSIONS',
    subtext: 'Total brand exposures delivered across campaigns',
  },
  {
    value: '1.7M+',
    numericValue: 1.7,
    suffix: 'M+',
    decimals: 1,
    label: 'PROFILE VISITS',
    subtext: 'Direct traffic driven to client brand storefronts',
  },
  {
    value: '164K+',
    numericValue: 164,
    suffix: 'K+',
    decimals: 0,
    label: 'QUALIFIED INQUIRIES',
    subtext: 'Direct messages, leads & purchase inquiries generated',
  },
  {
    value: '78K+',
    numericValue: 78,
    suffix: 'K+',
    decimals: 0,
    label: 'FOLLOWERS ADDED',
    subtext: 'Net organic community growth built for clients',
  },
  {
    value: '620+',
    numericValue: 620,
    suffix: '+',
    decimals: 0,
    label: 'CAMPAIGNS EXECUTED',
    subtext: 'Targeted organic & sponsored executions launched',
  },
];

export const CLIENTS: ClientItem[] = [
  { name: 'TARINIKA', category: 'Jewellery & Luxury' },
  { name: 'GULAB TRIBE', category: 'Fashion & Apparel' },
  { name: 'MAVURI', category: 'Fashion & Apparel' },
  { name: 'KANCHI KAMAKSHI', category: 'Fashion & Apparel' },
  { name: 'GENZ RAMYUN', category: 'Food & Hospitality' },
  { name: 'LOOKIN', category: 'Lifestyle & Retail' },
  { name: 'ECO BAXA', category: 'Lifestyle & Retail' },
  { name: 'JUST MINIS', category: 'Food & Hospitality' },
  { name: 'FUSION POINT', category: 'Food & Hospitality' },
  { name: 'PLANTAE', category: 'Lifestyle & Retail' },
  { name: 'DESIGNHOLIC', category: 'Lifestyle & Retail' },
  { name: 'TWINKLE THREADS', category: 'Fashion & Apparel' },
  { name: 'CREME BERRY', category: 'Food & Hospitality' },
  { name: 'MF KHAN', category: 'Fashion & Apparel' },
  { name: 'CMR JEWELLERY', category: 'Jewellery & Luxury' },
  { name: 'BLISS GOA', category: 'Food & Hospitality' },
  { name: 'RATH AVANEE', category: 'Fashion & Apparel' },
  { name: 'BEYOND MILES', category: 'Lifestyle & Retail' },
  { name: 'SWEEJA JEWELLERY', category: 'Jewellery & Luxury' },
  { name: 'VASTRA BOUTIQUE', category: 'Fashion & Apparel' },
  { name: 'PRISM COLLEGE', category: 'Education & Enterprise' },
  { name: 'FTV BEAUTY AND AESTHETIC', category: 'Jewellery & Luxury' },
];
