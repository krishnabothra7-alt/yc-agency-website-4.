import React from 'react';
import { ArrowUp, ArrowUpRight } from 'lucide-react';
import { AGENCY_INFO } from '../data/agencyData.ts';

export const Footer: React.FC = () => {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="bg-[#0D0D0D] text-[#FAF9F6] border-t border-[#0D0D0D] pt-20 pb-12">
      <div className="max-w-7xl mx-auto px-6 md:px-10">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-12 pb-16 border-b border-white/10">
          {/* Brand Column */}
          <div className="md:col-span-5 flex flex-col justify-between space-y-6">
            <div>
              <div className="font-serif text-5xl sm:text-6xl text-white font-normal tracking-tight mb-2">
                YC<span className="text-[#E11D74]">.</span>
              </div>
              <div className="text-xs font-mono tracking-[0.25em] text-[#E11D74] uppercase font-semibold">
                BUILDING AUTHORITY IN THE DIGITAL AGE
              </div>
            </div>

            <p className="text-xs sm:text-sm text-white/50 max-w-sm leading-relaxed font-light">
              Founded by Yashvee Baid and Chetna Bothra. Specialized Meta and LinkedIn marketing engineered for real business growth.
            </p>
          </div>

          {/* Platforms Column */}
          <div className="md:col-span-4">
            <div className="text-[11px] font-mono tracking-[0.2em] text-white/40 uppercase mb-6">
              PLATFORMS &amp; PRESENCE
            </div>

            <ul className="space-y-3 text-sm">
              {AGENCY_INFO.platforms.map((platform) => (
                <li key={platform.name}>
                  <a
                    href={platform.href}
                    target="_blank"
                    rel="noreferrer"
                    className="group inline-flex items-center gap-2 text-white/80 hover:text-[#E11D74] transition-colors"
                  >
                    <span>{platform.name}</span>
                    <ArrowUpRight className="w-3.5 h-3.5 text-white/30 group-hover:text-[#E11D74] transition-colors" />
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Quick Connect & Back to top */}
          <div className="md:col-span-3 flex flex-col justify-between space-y-8">
            <div>
              <div className="text-[11px] font-mono tracking-[0.2em] text-white/40 uppercase mb-4">
                INQUIRIES
              </div>
              <a
                href="mailto:ycagencyinfo@gmail.com"
                className="text-sm text-white/80 hover:text-[#E11D74] transition-colors block mb-2"
              >
                ycagencyinfo@gmail.com
              </a>
              <div className="text-xs text-white/40 font-mono">
                Mumbai · Hyderabad · Global
              </div>
            </div>

            <div>
              <button
                onClick={scrollToTop}
                className="group flex items-center gap-2 text-xs font-mono tracking-wider uppercase text-white/50 hover:text-white transition-colors cursor-pointer"
              >
                <span>BACK TO TOP</span>
                <span className="w-6 h-6 rounded-full border border-white/20 flex items-center justify-center group-hover:border-white group-hover:bg-white group-hover:text-[#0D0D0D] transition-all">
                  <ArrowUp className="w-3 h-3" />
                </span>
              </button>
            </div>
          </div>
        </div>

        {/* Bottom Copyright & Legal line */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs font-mono text-white/40">
          <div>
            Copyright © {new Date().getFullYear()} YC. All rights reserved.
          </div>
          <div className="flex items-center gap-6">
            <span>META &amp; LINKEDIN AGENCY</span>
            <span>·</span>
            <span>ALL RIGHTS RESERVED</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
