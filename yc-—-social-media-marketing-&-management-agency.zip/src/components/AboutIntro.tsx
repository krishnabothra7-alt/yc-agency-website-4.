import React, { useState } from 'react';
import { ArrowUpRight, Camera, User, Sparkles } from 'lucide-react';
import { AGENCY_INFO } from '../data/agencyData.ts';

interface AboutIntroProps {
  onOpenContact: () => void;
}

export const AboutIntro: React.FC<AboutIntroProps> = ({ onOpenContact }) => {
  // Allow user to upload or toggle preview of their real photos if they wish, with clean default placeholder
  const [yashveePhoto, setYashveePhoto] = useState<string | null>(null);
  const [chetnaPhoto, setChetnaPhoto] = useState<string | null>(null);

  const handlePhotoUpload = (
    e: React.ChangeEvent<HTMLInputElement>,
    setter: (url: string) => void
  ) => {
    const file = e.target.files?.[0];
    if (file) {
      const url = URL.createObjectURL(file);
      setter(url);
    }
  };

  return (
    <section id="about" className="py-24 md:py-32 border-b border-[#0D0D0D]/10 relative">
      <div className="max-w-7xl mx-auto px-6 md:px-10">
        {/* Section Label */}
        <div className="flex items-center gap-3 mb-8">
          <span className="text-[11px] font-mono tracking-[0.25em] text-[#E11D74] font-semibold uppercase">
            ABOUT YC
          </span>
          <span className="w-12 h-[1px] bg-[#E11D74]/40"></span>
          <span className="text-[11px] font-mono tracking-widest text-[#0D0D0D]/40 uppercase hidden sm:inline">
            CO-FOUNDERS &amp; PHILOSOPHY
          </span>
        </div>

        {/* Large Headline */}
        <h2 className="font-serif text-4xl sm:text-5xl md:text-6xl lg:text-7xl leading-[1.02] text-[#0D0D0D] font-normal tracking-tight text-balance max-w-5xl mb-16 md:mb-20">
          SOCIAL MEDIA SHOULD DO MORE <br />
          <span className="italic">THAN FILL YOUR FEED.</span>
        </h2>

        {/* Editorial Two-Column Layout */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-start">
          {/* Left Column: Narrative Copy */}
          <div className="lg:col-span-6 flex flex-col justify-between space-y-8 text-[#0D0D0D]/80">
            <p className="text-xl sm:text-2xl font-light text-[#0D0D0D] leading-relaxed border-l-2 border-[#E11D74] pl-6 py-1">
              YC is a dynamic agency founded by Yashvee Baid and Chetna Bothra, with a shared passion for helping businesses thrive on social media.
            </p>

            <div className="space-y-6 text-base sm:text-lg leading-relaxed text-[#0D0D0D]/75">
              <p>
                <strong className="text-[#0D0D0D] font-semibold">Yashvee</strong> leads Instagram, Facebook, WhatsApp and LinkedIn strategy and management, helping clients build a strong brand presence and connect with the right audience.
              </p>
              <p>
                <strong className="text-[#0D0D0D] font-semibold">Chetna</strong> leads Instagram ad creative and strategy, crafting visuals and campaigns that convert.
              </p>
              <p className="pt-2 text-[#0D0D0D] font-medium">
                Together, we offer a full range of Meta and LinkedIn marketing services helping businesses grow and succeed across every platform that matters.
              </p>
            </div>

            {/* Quick Action & Contact Hint */}
            <div className="pt-6 border-t border-[#0D0D0D]/10 flex flex-wrap items-center gap-6">
              <button
                onClick={onOpenContact}
                className="group inline-flex items-center gap-2 text-xs font-semibold tracking-[0.16em] uppercase text-[#0D0D0D] hover:text-[#E11D74] transition-colors cursor-pointer"
              >
                <span>LET&apos;S WORK TOGETHER</span>
                <ArrowUpRight className="w-4 h-4 transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
              </button>

              <span className="text-xs font-mono text-[#0D0D0D]/40">
                DIRECT FOUNDER CONSULTATION
              </span>
            </div>
          </div>

          {/* Right Column: Editorial Space for Founder Photographs */}
          <div className="lg:col-span-6">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
              {/* Founder 1: Yashvee Baid */}
              <div className="group border border-[#0D0D0D]/20 bg-white p-5 flex flex-col justify-between hover:border-[#0D0D0D] transition-all duration-300">
                {/* Photo Placeholder Frame */}
                <div className="relative aspect-[4/5] bg-[#F4F2EC] border border-[#0D0D0D]/10 overflow-hidden flex flex-col items-center justify-center p-6 text-center">
                  {yashveePhoto ? (
                    <img
                      src={yashveePhoto}
                      alt="Yashvee Baid - Founder of YC"
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <div className="flex flex-col items-center justify-center text-[#0D0D0D]/60 space-y-3">
                      <div className="w-16 h-16 rounded-full border border-dashed border-[#0D0D0D]/30 flex items-center justify-center bg-white/60">
                        <User className="w-7 h-7 text-[#0D0D0D]/60" />
                      </div>
                      <div className="font-serif text-2xl text-[#0D0D0D]">YB</div>
                      <div className="text-[10px] font-mono tracking-wider text-[#0D0D0D]/50 uppercase">
                        PORTRAIT PLACEHOLDER
                      </div>
                      <label className="text-[10px] font-semibold text-[#E11D74] hover:underline cursor-pointer flex items-center gap-1 mt-2">
                        <Camera className="w-3 h-3" />
                        <span>Upload Photo</span>
                        <input
                          type="file"
                          accept="image/*"
                          className="hidden"
                          onChange={(e) => handlePhotoUpload(e, setYashveePhoto)}
                        />
                      </label>
                    </div>
                  )}

                  {/* Corner Accent */}
                  <div className="absolute top-2 left-2 text-[9px] font-mono text-[#0D0D0D]/40">01 / YB</div>
                  <div className="absolute bottom-2 right-2 text-[9px] font-mono text-[#E11D74]">STRATEGY</div>
                </div>

                {/* Founder Bio Stamp */}
                <div className="pt-5">
                  <div className="text-[10px] font-mono tracking-[0.2em] text-[#E11D74] font-semibold uppercase mb-1">
                    FOUNDER
                  </div>
                  <h3 className="font-serif text-2xl text-[#0D0D0D] tracking-tight mb-2">
                    Yashvee Baid
                  </h3>
                  <p className="text-xs text-[#0D0D0D]/70 leading-relaxed">
                    Strategy and management across Instagram, Facebook, WhatsApp, and LinkedIn.
                  </p>
                </div>
              </div>

              {/* Founder 2: Chetna Bothra */}
              <div className="group border border-[#0D0D0D]/20 bg-white p-5 flex flex-col justify-between hover:border-[#0D0D0D] transition-all duration-300">
                {/* Photo Placeholder Frame */}
                <div className="relative aspect-[4/5] bg-[#F4F2EC] border border-[#0D0D0D]/10 overflow-hidden flex flex-col items-center justify-center p-6 text-center">
                  {chetnaPhoto ? (
                    <img
                      src={chetnaPhoto}
                      alt="Chetna Bothra - Founder of YC"
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <div className="flex flex-col items-center justify-center text-[#0D0D0D]/60 space-y-3">
                      <div className="w-16 h-16 rounded-full border border-dashed border-[#0D0D0D]/30 flex items-center justify-center bg-white/60">
                        <User className="w-7 h-7 text-[#0D0D0D]/60" />
                      </div>
                      <div className="font-serif text-2xl text-[#0D0D0D]">CB</div>
                      <div className="text-[10px] font-mono tracking-wider text-[#0D0D0D]/50 uppercase">
                        PORTRAIT PLACEHOLDER
                      </div>
                      <label className="text-[10px] font-semibold text-[#E11D74] hover:underline cursor-pointer flex items-center gap-1 mt-2">
                        <Camera className="w-3 h-3" />
                        <span>Upload Photo</span>
                        <input
                          type="file"
                          accept="image/*"
                          className="hidden"
                          onChange={(e) => handlePhotoUpload(e, setChetnaPhoto)}
                        />
                      </label>
                    </div>
                  )}

                  {/* Corner Accent */}
                  <div className="absolute top-2 left-2 text-[9px] font-mono text-[#0D0D0D]/40">02 / CB</div>
                  <div className="absolute bottom-2 right-2 text-[9px] font-mono text-[#E11D74]">CREATIVE</div>
                </div>

                {/* Founder Bio Stamp */}
                <div className="pt-5">
                  <div className="text-[10px] font-mono tracking-[0.2em] text-[#E11D74] font-semibold uppercase mb-1">
                    FOUNDER
                  </div>
                  <h3 className="font-serif text-2xl text-[#0D0D0D] tracking-tight mb-2">
                    Chetna Bothra
                  </h3>
                  <p className="text-xs text-[#0D0D0D]/70 leading-relaxed">
                    Instagram ad creative and performance strategy, crafting visuals and campaigns that convert.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
