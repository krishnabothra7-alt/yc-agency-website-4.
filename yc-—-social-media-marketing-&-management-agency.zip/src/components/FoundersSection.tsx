import React, { useState } from 'react';
import { Camera, Phone, Mail, MessageCircle, ArrowUpRight, User } from 'lucide-react';
import { AGENCY_INFO } from '../data/agencyData.ts';

export const FoundersSection: React.FC = () => {
  const [photoYashvee, setPhotoYashvee] = useState<string | null>(null);
  const [photoChetna, setPhotoChetna] = useState<string | null>(null);

  const handleUpload = (
    e: React.ChangeEvent<HTMLInputElement>,
    setter: (val: string) => void
  ) => {
    const file = e.target.files?.[0];
    if (file) {
      setter(URL.createObjectURL(file));
    }
  };

  return (
    <section className="py-24 md:py-36 border-b border-[#0D0D0D]/10 bg-[#FAF9F6]">
      <div className="max-w-7xl mx-auto px-6 md:px-10">
        {/* Section Label */}
        <div className="flex items-center gap-3 mb-6">
          <span className="text-[11px] font-mono tracking-[0.25em] text-[#E11D74] font-semibold uppercase">
            THE PEOPLE BEHIND YC
          </span>
          <span className="w-12 h-[1px] bg-[#E11D74]/40" />
          <span className="text-[11px] font-mono tracking-widest text-[#0D0D0D]/40 uppercase hidden sm:inline">
            LEADERSHIP &amp; EXPERTISE
          </span>
        </div>

        {/* Headline */}
        <div className="mb-16 md:mb-24">
          <h2 className="font-serif text-4xl sm:text-5xl md:text-6xl lg:text-7xl leading-[1.02] text-[#0D0D0D] font-normal tracking-tight text-balance">
            TWO MINDS. <br />
            <span className="italic">ONE VISION.</span>
          </h2>
        </div>

        {/* Two Premium Founder Profiles */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-16">
          {/* Founder 1: Yashvee Baid */}
          <div className="border border-[#0D0D0D]/20 bg-white p-8 md:p-10 flex flex-col justify-between group hover:border-[#0D0D0D] transition-all duration-300 shadow-[4px_4px_0px_#0D0D0D]/5">
            <div>
              {/* Image Frame Placeholder */}
              <div className="relative aspect-[3/4] bg-[#F4F2EC] border border-[#0D0D0D]/15 overflow-hidden flex flex-col items-center justify-center p-8 mb-8 text-center">
                {photoYashvee ? (
                  <img
                    src={photoYashvee}
                    alt="Yashvee Baid - Founder"
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <div className="flex flex-col items-center justify-center text-[#0D0D0D]/70 space-y-4">
                    <div className="w-20 h-20 rounded-full border border-dashed border-[#0D0D0D]/30 flex items-center justify-center bg-white/70">
                      <User className="w-9 h-9 text-[#0D0D0D]/60" />
                    </div>
                    <div className="font-serif text-4xl text-[#0D0D0D]">YB</div>
                    <div className="text-xs font-mono tracking-widest text-[#0D0D0D]/50 uppercase">
                      PORTRAIT PLACEHOLDER
                    </div>
                    <label className="text-xs font-semibold text-[#E11D74] hover:underline cursor-pointer flex items-center gap-1.5 mt-2 bg-white/80 px-3 py-1.5 border border-[#0D0D0D]/10">
                      <Camera className="w-3.5 h-3.5" />
                      <span>Upload Real Photo</span>
                      <input
                        type="file"
                        accept="image/*"
                        className="hidden"
                        onChange={(e) => handleUpload(e, setPhotoYashvee)}
                      />
                    </label>
                  </div>
                )}

                {/* Frame Badges */}
                <div className="absolute top-3 left-3 text-[10px] font-mono tracking-wider text-[#0D0D0D]/50 bg-white/70 px-2 py-0.5">
                  01 / YB
                </div>
                <div className="absolute top-3 right-3 text-[10px] font-mono text-[#E11D74] bg-white/70 px-2 py-0.5 font-semibold">
                  STRATEGY
                </div>
              </div>

              {/* Founder Header */}
              <div className="text-[11px] font-mono tracking-[0.2em] text-[#E11D74] font-semibold uppercase mb-2">
                FOUNDER
              </div>

              <h3 className="font-serif text-3xl sm:text-4xl text-[#0D0D0D] tracking-tight mb-4 font-normal">
                YASHVEE BAID
              </h3>

              <p className="text-base text-[#0D0D0D]/75 leading-relaxed font-normal mb-8">
                Yashvee leads Instagram, Facebook, WhatsApp and LinkedIn strategy and management, helping clients build a strong brand presence and connect with the right audience.
              </p>
            </div>

            {/* Direct Contact Actions */}
            <div className="pt-6 border-t border-[#0D0D0D]/10 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <a
                href="tel:+919989798548"
                className="inline-flex items-center gap-2 text-xs font-semibold tracking-wider text-[#0D0D0D] hover:text-[#E11D74] transition-colors"
              >
                <Phone className="w-3.5 h-3.5 text-[#E11D74]" />
                <span>+91 99897 98548</span>
              </a>

              <a
                href="https://wa.me/919989798548"
                target="_blank"
                rel="noreferrer"
                className="inline-flex items-center gap-2 text-xs font-semibold tracking-wider text-[#0D0D0D] hover:text-[#E11D74] transition-colors"
              >
                <MessageCircle className="w-3.5 h-3.5 text-[#25D366]" />
                <span>CONNECT ON WHATSAPP</span>
              </a>
            </div>
          </div>

          {/* Founder 2: Chetna Bothra */}
          <div className="border border-[#0D0D0D]/20 bg-white p-8 md:p-10 flex flex-col justify-between group hover:border-[#0D0D0D] transition-all duration-300 shadow-[4px_4px_0px_#0D0D0D]/5">
            <div>
              {/* Image Frame Placeholder */}
              <div className="relative aspect-[3/4] bg-[#F4F2EC] border border-[#0D0D0D]/15 overflow-hidden flex flex-col items-center justify-center p-8 mb-8 text-center">
                {photoChetna ? (
                  <img
                    src={photoChetna}
                    alt="Chetna Bothra - Founder"
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <div className="flex flex-col items-center justify-center text-[#0D0D0D]/70 space-y-4">
                    <div className="w-20 h-20 rounded-full border border-dashed border-[#0D0D0D]/30 flex items-center justify-center bg-white/70">
                      <User className="w-9 h-9 text-[#0D0D0D]/60" />
                    </div>
                    <div className="font-serif text-4xl text-[#0D0D0D]">CB</div>
                    <div className="text-xs font-mono tracking-widest text-[#0D0D0D]/50 uppercase">
                      PORTRAIT PLACEHOLDER
                    </div>
                    <label className="text-xs font-semibold text-[#E11D74] hover:underline cursor-pointer flex items-center gap-1.5 mt-2 bg-white/80 px-3 py-1.5 border border-[#0D0D0D]/10">
                      <Camera className="w-3.5 h-3.5" />
                      <span>Upload Real Photo</span>
                      <input
                        type="file"
                        accept="image/*"
                        className="hidden"
                        onChange={(e) => handleUpload(e, setPhotoChetna)}
                      />
                    </label>
                  </div>
                )}

                {/* Frame Badges */}
                <div className="absolute top-3 left-3 text-[10px] font-mono tracking-wider text-[#0D0D0D]/50 bg-white/70 px-2 py-0.5">
                  02 / CB
                </div>
                <div className="absolute top-3 right-3 text-[10px] font-mono text-[#E11D74] bg-white/70 px-2 py-0.5 font-semibold">
                  AD CREATIVE
                </div>
              </div>

              {/* Founder Header */}
              <div className="text-[11px] font-mono tracking-[0.2em] text-[#E11D74] font-semibold uppercase mb-2">
                FOUNDER
              </div>

              <h3 className="font-serif text-3xl sm:text-4xl text-[#0D0D0D] tracking-tight mb-4 font-normal">
                CHETNA BOTHRA
              </h3>

              <p className="text-base text-[#0D0D0D]/75 leading-relaxed font-normal mb-8">
                Chetna leads Instagram ad creative and strategy, crafting visuals and campaigns that convert.
              </p>
            </div>

            {/* Direct Contact Actions */}
            <div className="pt-6 border-t border-[#0D0D0D]/10 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <a
                href="tel:+919581314751"
                className="inline-flex items-center gap-2 text-xs font-semibold tracking-wider text-[#0D0D0D] hover:text-[#E11D74] transition-colors"
              >
                <Phone className="w-3.5 h-3.5 text-[#E11D74]" />
                <span>+91 95813 14751</span>
              </a>

              <a
                href="https://wa.me/919581314751"
                target="_blank"
                rel="noreferrer"
                className="inline-flex items-center gap-2 text-xs font-semibold tracking-wider text-[#0D0D0D] hover:text-[#E11D74] transition-colors"
              >
                <MessageCircle className="w-3.5 h-3.5 text-[#25D366]" />
                <span>CONNECT ON WHATSAPP</span>
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
