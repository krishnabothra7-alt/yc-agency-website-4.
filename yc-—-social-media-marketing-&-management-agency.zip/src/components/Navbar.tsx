import React, { useState, useEffect } from 'react';
import { ArrowUpRight, Menu, X, ArrowRight } from 'lucide-react';
import { AGENCY_INFO } from '../data/agencyData.ts';

interface NavbarProps {
  onOpenContact: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({ onOpenContact }) => {
  const [scrolled, setScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [activeSection, setActiveSection] = useState('home');

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 30);

      const sections = ['home', 'services', 'work', 'about', 'results', 'contact'];
      const scrollPos = window.scrollY + 200;

      for (const section of sections) {
        const el = document.getElementById(section);
        if (el) {
          const top = el.offsetTop;
          const height = el.offsetHeight;
          if (scrollPos >= top && scrollPos < top + height) {
            setActiveSection(section);
            break;
          }
        }
      }
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { label: 'HOME', href: '#home' },
    { label: 'SERVICES', href: '#services' },
    { label: 'WORK', href: '#work' },
    { label: 'ABOUT', href: '#about' },
    { label: 'RESULTS', href: '#results' },
    { label: 'CONTACT', href: '#contact' },
  ];

  const handleNavClick = (href: string) => {
    setMobileMenuOpen(false);
    const targetId = href.replace('#', '');
    const element = document.getElementById(targetId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <>
      <header
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
          scrolled
            ? 'bg-[#FAF9F6]/90 backdrop-blur-md border-b border-[#0D0D0D]/10 py-3 shadow-[0_2px_12px_rgba(0,0,0,0.03)]'
            : 'bg-transparent py-5'
        }`}
      >
        <div className="max-w-7xl mx-auto px-6 md:px-10 flex items-center justify-between">
          {/* Zone 1: Single element wordmark */}
          <a
            href="#home"
            className="group flex items-baseline gap-1 focus:outline-none focus-visible:ring-2 focus-visible:ring-[#E11D74]"
            aria-label="YC Agency Home"
          >
            <span className="font-serif text-3xl md:text-4xl font-normal tracking-tight text-[#0D0D0D] group-hover:text-[#E11D74] transition-colors duration-200">
              YC
            </span>
            <span className="w-1.5 h-1.5 rounded-full bg-[#E11D74] inline-block transition-transform duration-200 group-hover:scale-125"></span>
          </a>

          {/* Zone 2: Navigation Links (Clean text, single line) */}
          <nav
            aria-label="Main Navigation"
            className="hidden md:flex items-center gap-7 lg:gap-9 text-xs font-medium tracking-[0.18em] text-[#0D0D0D]/70"
          >
            {navLinks.map((link) => {
              const isActive = activeSection === link.href.replace('#', '');
              return (
                <a
                  key={link.label}
                  href={link.href}
                  onClick={(e) => {
                    e.preventDefault();
                    handleNavClick(link.href);
                  }}
                  className={`relative py-1 transition-colors duration-200 hover:text-[#0D0D0D] whitespace-nowrap ${
                    isActive ? 'text-[#0D0D0D] font-semibold' : ''
                  }`}
                >
                  {link.label}
                  {isActive && (
                    <span className="absolute bottom-0 left-0 w-full h-[1.5px] bg-[#E11D74]" />
                  )}
                </a>
              );
            })}
          </nav>

          {/* Zone 3: Primary Action CTA */}
          <div className="hidden sm:flex items-center gap-4">
            <button
              onClick={onOpenContact}
              className="group relative inline-flex items-center gap-2 px-5 py-2.5 text-xs font-semibold tracking-[0.14em] uppercase text-white bg-[#0D0D0D] hover:bg-[#E11D74] transition-all duration-200 rounded-none shadow-sm cursor-pointer whitespace-nowrap focus:outline-none focus-visible:ring-2 focus-visible:ring-[#E11D74]"
            >
              <span>LET&apos;S WORK TOGETHER</span>
              <ArrowUpRight className="w-3.5 h-3.5 transition-transform duration-200 group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
            </button>
          </div>

          {/* Mobile Menu Toggle Button */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            aria-label={mobileMenuOpen ? 'Close Menu' : 'Open Menu'}
            className="md:hidden p-2 text-[#0D0D0D] hover:text-[#E11D74] focus:outline-none focus-visible:ring-2 focus-visible:ring-[#E11D74]"
          >
            {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </header>

      {/* Mobile Editorial Overlay Menu */}
      {mobileMenuOpen && (
        <div
          role="dialog"
          aria-modal="true"
          aria-label="Mobile navigation menu"
          className="fixed inset-0 z-40 bg-[#FAF9F6] flex flex-col justify-between pt-24 pb-8 px-6 md:hidden animate-in fade-in duration-200"
        >
          <div className="flex flex-col gap-6">
            <span className="text-[11px] font-semibold tracking-[0.25em] text-[#0D0D0D]/40 uppercase">
              NAVIGATION
            </span>
            <div className="flex flex-col gap-4">
              {navLinks.map((link, idx) => (
                <a
                  key={link.label}
                  href={link.href}
                  onClick={(e) => {
                    e.preventDefault();
                    handleNavClick(link.href);
                  }}
                  className="group flex items-baseline justify-between border-b border-[#0D0D0D]/10 pb-3"
                >
                  <span className="font-serif text-3xl text-[#0D0D0D] group-hover:text-[#E11D74] transition-colors">
                    {link.label}
                  </span>
                  <span className="text-xs font-mono text-[#0D0D0D]/40 group-hover:text-[#E11D74]">
                    0{idx + 1}
                  </span>
                </a>
              ))}
            </div>
          </div>

          <div className="flex flex-col gap-5 pt-6 border-t border-[#0D0D0D]/10">
            <button
              onClick={() => {
                setMobileMenuOpen(false);
                onOpenContact();
              }}
              className="w-full flex items-center justify-center gap-2 py-3.5 px-6 text-xs font-semibold tracking-[0.16em] uppercase text-white bg-[#0D0D0D] hover:bg-[#E11D74] transition-colors"
            >
              <span>LET&apos;S WORK TOGETHER</span>
              <ArrowRight className="w-4 h-4" />
            </button>

            <div className="flex items-center justify-between text-xs text-[#0D0D0D]/60 pt-2">
              <a href="mailto:ycagencyinfo@gmail.com" className="hover:text-[#E11D74] transition-colors">
                ycagencyinfo@gmail.com
              </a>
              <span className="text-[10px] tracking-wider text-[#0D0D0D]/40">YC AGENCY</span>
            </div>
          </div>
        </div>
      )}
    </>
  );
};
