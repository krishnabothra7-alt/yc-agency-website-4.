import React, { useState } from 'react';
import { ArrowUpRight, Mail, Phone, MessageSquare, Send, CheckCircle2 } from 'lucide-react';
import { AGENCY_INFO } from '../data/agencyData.ts';

interface ContactCTAProps {
  onOpenModal: () => void;
  initialContext?: string;
}

export const ContactCTA: React.FC<ContactCTAProps> = ({ onOpenModal, initialContext }) => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    brand: '',
    message: initialContext || '',
    platforms: ['Instagram', 'LinkedIn'],
  });
  const [submitted, setSubmitted] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const togglePlatform = (plat: string) => {
    setFormData((prev) => {
      const exists = prev.platforms.includes(plat);
      return {
        ...prev,
        platforms: exists ? prev.platforms.filter((p) => p !== plat) : [...prev.platforms, plat],
      };
    });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    // Simulate reliable dispatch
    setTimeout(() => {
      setIsSubmitting(false);
      setSubmitted(true);
    }, 600);
  };

  return (
    <section id="contact" className="py-24 md:py-36 bg-[#FAF9F6] relative">
      <div className="max-w-7xl mx-auto px-6 md:px-10">
        {/* Large Editorial Headline */}
        <div className="border-b border-[#0D0D0D]/10 pb-16 mb-16">
          <div className="flex items-center gap-3 mb-6">
            <span className="text-[11px] font-mono tracking-[0.25em] text-[#E11D74] font-semibold uppercase">
              GET IN TOUCH
            </span>
            <span className="w-12 h-[1px] bg-[#E11D74]/40" />
            <span className="text-[11px] font-mono tracking-widest text-[#0D0D0D]/40 uppercase hidden sm:inline">
              START A CONVERSATION
            </span>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-end justify-between">
            <div className="lg:col-span-8">
              <h2 className="font-serif text-5xl sm:text-6xl md:text-7xl lg:text-8xl leading-[0.95] text-[#0D0D0D] font-normal tracking-tight text-balance">
                READY TO <br />
                <span className="italic font-serif text-[#E11D74]">GROW?</span>
              </h2>
            </div>

            <div className="lg:col-span-4">
              <p className="text-base sm:text-lg text-[#0D0D0D]/75 font-normal leading-relaxed text-pretty mb-6">
                Reach out anytime. We&apos;re happy to answer questions or map out a plan.
              </p>

              <button
                onClick={onOpenModal}
                className="group inline-flex items-center gap-3 px-8 py-4 text-xs font-semibold tracking-[0.16em] uppercase text-white bg-[#0D0D0D] hover:bg-[#E11D74] transition-all duration-300 shadow-sm cursor-pointer whitespace-nowrap"
              >
                <span>LET&apos;S TALK</span>
                <ArrowUpRight className="w-4 h-4 transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
              </button>
            </div>
          </div>
        </div>

        {/* Editorial Split: Direct Directory & Quick Inbound Brief Form */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-start">
          {/* Left Column: Direct Founder Contacts */}
          <div className="lg:col-span-5 space-y-10">
            <div>
              <div className="text-[11px] font-mono tracking-[0.2em] text-[#0D0D0D]/50 uppercase mb-4">
                PRIMARY EMAIL
              </div>
              <a
                href="mailto:ycagencyinfo@gmail.com"
                className="font-serif text-2xl sm:text-3xl text-[#0D0D0D] hover:text-[#E11D74] transition-colors flex items-center gap-2 group"
              >
                <span>ycagencyinfo@gmail.com</span>
                <ArrowUpRight className="w-5 h-5 text-transparent group-hover:text-[#E11D74] transition-colors" />
              </a>
            </div>

            <div className="border-t border-[#0D0D0D]/10 pt-8 space-y-8">
              <div className="text-[11px] font-mono tracking-[0.2em] text-[#0D0D0D]/50 uppercase mb-4">
                FOUNDER DIRECT LINES
              </div>

              {/* Chetna Bothra */}
              <div className="border border-[#0D0D0D]/10 p-6 bg-white hover:border-[#0D0D0D] transition-colors">
                <div className="flex items-center justify-between text-[10px] font-mono tracking-wider text-[#E11D74] uppercase font-semibold mb-1">
                  <span>CHETNA BOTHRA</span>
                  <span>AD CREATIVE &amp; STRATEGY</span>
                </div>
                <a
                  href="tel:+919581314751"
                  className="font-serif text-2xl text-[#0D0D0D] hover:text-[#E11D74] transition-colors block mb-3"
                >
                  +91 95813 14751
                </a>
                <div className="flex items-center gap-4 text-xs font-mono">
                  <a
                    href="tel:+919581314751"
                    className="text-[#0D0D0D]/70 hover:text-[#E11D74] underline"
                  >
                    Direct Call
                  </a>
                  <span>·</span>
                  <a
                    href="https://wa.me/919581314751?text=Hi%20Chetna,%20I'm%20reaching%20out%20from%20the%20YC%20website%20to%20discuss%20our%20social%20media%20marketing."
                    target="_blank"
                    rel="noreferrer"
                    className="text-[#25D366] hover:underline"
                  >
                    WhatsApp Chat
                  </a>
                </div>
              </div>

              {/* Yashvee Baid */}
              <div className="border border-[#0D0D0D]/10 p-6 bg-white hover:border-[#0D0D0D] transition-colors">
                <div className="flex items-center justify-between text-[10px] font-mono tracking-wider text-[#E11D74] uppercase font-semibold mb-1">
                  <span>YASHVEE BAID</span>
                  <span>STRATEGY &amp; MANAGEMENT</span>
                </div>
                <a
                  href="tel:+919989798548"
                  className="font-serif text-2xl text-[#0D0D0D] hover:text-[#E11D74] transition-colors block mb-3"
                >
                  +91 99897 98548
                </a>
                <div className="flex items-center gap-4 text-xs font-mono">
                  <a
                    href="tel:+919989798548"
                    className="text-[#0D0D0D]/70 hover:text-[#E11D74] underline"
                  >
                    Direct Call
                  </a>
                  <span>·</span>
                  <a
                    href="https://wa.me/919989798548?text=Hi%20Yashvee,%20I'm%20reaching%20out%20from%20the%20YC%20website%20to%20discuss%20our%20social%20media%20marketing."
                    target="_blank"
                    rel="noreferrer"
                    className="text-[#25D366] hover:underline"
                  >
                    WhatsApp Chat
                  </a>
                </div>
              </div>
            </div>
          </div>

          {/* Right Column: Interactive Project Inquiry Box */}
          <div className="lg:col-span-7 bg-white border border-[#0D0D0D]/15 p-8 sm:p-10 shadow-[6px_6px_0px_#0D0D0D]">
            <div className="flex items-center justify-between pb-6 border-b border-[#0D0D0D]/10 mb-8">
              <span className="text-[11px] font-mono tracking-[0.2em] text-[#0D0D0D]/50 uppercase">
                DIRECT INQUIRY BRIEF
              </span>
              <span className="text-[11px] font-mono text-[#E11D74] font-semibold">
                TYPICAL RESPONSE: &lt; 24H
              </span>
            </div>

            {submitted ? (
              <div className="py-12 flex flex-col items-center text-center space-y-4 animate-in fade-in duration-300">
                <CheckCircle2 className="w-12 h-12 text-[#E11D74]" />
                <h3 className="font-serif text-3xl text-[#0D0D0D]">Thank You!</h3>
                <p className="text-sm text-[#0D0D0D]/70 max-w-md leading-relaxed">
                  Your inquiry has been received. Yashvee or Chetna will review your brief and reach back out with initial strategy insights.
                </p>
                <button
                  onClick={() => setSubmitted(false)}
                  className="mt-4 px-6 py-2.5 text-xs font-semibold tracking-wider uppercase border border-[#0D0D0D] text-[#0D0D0D] hover:bg-[#0D0D0D] hover:text-white transition-colors"
                >
                  Send Another Message
                </button>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-xs font-mono uppercase tracking-wider text-[#0D0D0D]/60 mb-2">
                      Your Name *
                    </label>
                    <input
                      type="text"
                      required
                      placeholder="e.g. Radhika Sharma"
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      className="w-full px-4 py-3 bg-[#FAF9F6] border border-[#0D0D0D]/15 text-sm text-[#0D0D0D] focus:outline-none focus:border-[#E11D74] transition-colors"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-mono uppercase tracking-wider text-[#0D0D0D]/60 mb-2">
                      Email Address *
                    </label>
                    <input
                      type="email"
                      required
                      placeholder="e.g. name@brand.com"
                      value={formData.email}
                      onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                      className="w-full px-4 py-3 bg-[#FAF9F6] border border-[#0D0D0D]/15 text-sm text-[#0D0D0D] focus:outline-none focus:border-[#E11D74] transition-colors"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-xs font-mono uppercase tracking-wider text-[#0D0D0D]/60 mb-2">
                      Brand / Company Name
                    </label>
                    <input
                      type="text"
                      placeholder="e.g. Luxe Studio"
                      value={formData.brand}
                      onChange={(e) => setFormData({ ...formData, brand: e.target.value })}
                      className="w-full px-4 py-3 bg-[#FAF9F6] border border-[#0D0D0D]/15 text-sm text-[#0D0D0D] focus:outline-none focus:border-[#E11D74] transition-colors"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-mono uppercase tracking-wider text-[#0D0D0D]/60 mb-2">
                      Phone / WhatsApp Number
                    </label>
                    <input
                      type="tel"
                      placeholder="e.g. +91 98765 43210"
                      value={formData.phone}
                      onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                      className="w-full px-4 py-3 bg-[#FAF9F6] border border-[#0D0D0D]/15 text-sm text-[#0D0D0D] focus:outline-none focus:border-[#E11D74] transition-colors"
                    />
                  </div>
                </div>

                {/* Target Platforms Selection */}
                <div>
                  <label className="block text-xs font-mono uppercase tracking-wider text-[#0D0D0D]/60 mb-2.5">
                    Target Platforms of Focus
                  </label>
                  <div className="flex flex-wrap gap-2">
                    {['Instagram', 'Facebook', 'WhatsApp', 'LinkedIn', 'YouTube'].map((plat) => {
                      const isSelected = formData.platforms.includes(plat);
                      return (
                        <button
                          key={plat}
                          type="button"
                          onClick={() => togglePlatform(plat)}
                          className={`px-3.5 py-1.5 text-xs font-mono uppercase transition-colors cursor-pointer border ${
                            isSelected
                              ? 'bg-[#0D0D0D] text-white border-[#0D0D0D]'
                              : 'bg-white text-[#0D0D0D]/70 border-[#0D0D0D]/15 hover:border-[#E11D74]'
                          }`}
                        >
                          {isSelected ? `✓ ${plat}` : `+ ${plat}`}
                        </button>
                      );
                    })}
                  </div>
                </div>

                {/* Message / Brief */}
                <div>
                  <label className="block text-xs font-mono uppercase tracking-wider text-[#0D0D0D]/60 mb-2">
                    How Can We Help Your Brand? *
                  </label>
                  <textarea
                    rows={4}
                    required
                    placeholder="Tell us about your brand goals, target timeline, or existing social presence..."
                    value={formData.message}
                    onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                    className="w-full px-4 py-3 bg-[#FAF9F6] border border-[#0D0D0D]/15 text-sm text-[#0D0D0D] focus:outline-none focus:border-[#E11D74] transition-colors resize-none"
                  ></textarea>
                </div>

                {/* Submit Button */}
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="w-full flex items-center justify-center gap-2 py-4 px-6 text-xs font-semibold tracking-[0.16em] uppercase text-white bg-[#0D0D0D] hover:bg-[#E11D74] transition-all duration-300 disabled:opacity-50 cursor-pointer"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>{isSubmitting ? 'DISPATCHING BRIEF...' : 'SUBMIT PROJECT BRIEF'}</span>
                </button>
              </form>
            )}
          </div>
        </div>
      </div>
    </section>
  );
};
