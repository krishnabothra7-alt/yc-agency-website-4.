import React from 'react';
import { WHY_YC } from '../data/agencyData.ts';

export const WhyYCSection: React.FC = () => {
  return (
    <section className="py-24 md:py-32 border-b border-[#0D0D0D]/10 bg-[#FAF9F6] relative">
      <div className="max-w-7xl mx-auto px-6 md:px-10">
        {/* Section Label */}
        <div className="flex items-center gap-3 mb-6">
          <span className="text-[11px] font-mono tracking-[0.25em] text-[#E11D74] font-semibold uppercase">
            WHY YC
          </span>
          <span className="w-12 h-[1px] bg-[#E11D74]/40"></span>
          <span className="text-[11px] font-mono tracking-widest text-[#0D0D0D]/40 uppercase hidden sm:inline">
            CORE METHODOLOGY
          </span>
        </div>

        {/* Headline & Editorial Intro */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-16 items-start mb-20">
          <div className="lg:col-span-6">
            <h2 className="font-serif text-4xl sm:text-5xl md:text-6xl lg:text-7xl leading-[1.02] text-[#0D0D0D] font-normal tracking-tight text-balance">
              STRATEGY WITH <br />
              <span className="italic">PURPOSE.</span>
            </h2>
          </div>

          <div className="lg:col-span-6 flex flex-col justify-center">
            <p className="text-lg sm:text-xl text-[#0D0D0D]/80 leading-relaxed font-normal">
              At YC, we specialize in Meta and LinkedIn marketing and we take real pride in delivering dependable, top-notch results. We work with businesses of every size, from startups to large corporations, always focused on getting our clients the maximum return on their investment.
            </p>
          </div>
        </div>

        {/* Four Distinct Editorial Sections */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 border-t border-l border-[#0D0D0D]/15">
          {WHY_YC.map((item) => (
            <div
              key={item.number}
              className="group relative p-8 md:p-10 border-r border-b border-[#0D0D0D]/15 bg-white/40 hover:bg-white transition-all duration-300 flex flex-col justify-between min-h-[320px]"
            >
              {/* Top Row: Editorial Number & Category Accent */}
              <div>
                <div className="flex items-center justify-between pb-6 border-b border-[#0D0D0D]/10 mb-6">
                  <span className="font-mono text-xs tracking-wider text-[#0D0D0D]/40 group-hover:text-[#E11D74] transition-colors font-semibold">
                    {item.number}
                  </span>
                  <span className="w-1.5 h-1.5 rounded-full bg-transparent group-hover:bg-[#E11D74] transition-colors" />
                </div>

                <h3 className="font-serif text-2xl sm:text-3xl text-[#0D0D0D] font-normal tracking-tight mb-4 group-hover:text-[#0D0D0D] transition-colors">
                  {item.title}
                </h3>

                <p className="text-xs sm:text-sm text-[#0D0D0D]/70 leading-relaxed font-normal">
                  {item.description}
                </p>
              </div>

              {/* Bottom Subtle Highlight Tag (clean unboxed text, no pill) */}
              <div className="pt-6 mt-6 border-t border-[#0D0D0D]/5">
                <span className="text-[11px] font-mono tracking-wider text-[#E11D74] font-medium uppercase">
                  {item.highlight}
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
