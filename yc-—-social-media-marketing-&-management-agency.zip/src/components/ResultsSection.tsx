import React, { useState, useEffect, useRef } from 'react';
import { PRIMARY_METRICS, ADDITIONAL_METRICS } from '../data/agencyData.ts';

export const ResultsSection: React.FC = () => {
  const [hasAnimated, setHasAnimated] = useState(false);
  const [activeTab, setActiveTab] = useState<'core' | 'all'>('core');
  const sectionRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        if (entries[0].isIntersecting) {
          setHasAnimated(true);
        }
      },
      { threshold: 0.15 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  return (
    <section
      id="results"
      ref={sectionRef}
      className="py-24 md:py-36 bg-[#0D0D0D] text-[#FAF9F6] relative overflow-hidden"
    >
      {/* Subtle architectural vertical lines in the background */}
      <div className="absolute inset-0 pointer-events-none opacity-10">
        <div className="max-w-7xl mx-auto h-full px-6 md:px-10 grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="border-r border-white h-full" />
          <div className="border-r border-white h-full" />
          <div className="border-r border-white h-full" />
          <div className="border-r border-white h-full" />
        </div>
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-6 md:px-10">
        {/* Top Header Row with Segmented View Selector */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-8 mb-16 md:mb-24 pb-8 border-b border-white/10">
          <div>
            <div className="flex items-center gap-3 mb-4">
              <span className="text-[11px] font-mono tracking-[0.25em] text-[#E11D74] font-semibold uppercase">
                RESULTS
              </span>
              <span className="w-12 h-[1px] bg-[#E11D74]/60" />
              <span className="text-[11px] font-mono tracking-widest text-white/40 uppercase hidden sm:inline">
                VERIFIED IMPACT
              </span>
            </div>

            <h2 className="font-serif text-5xl sm:text-6xl md:text-7xl lg:text-8xl leading-[0.95] text-white font-normal tracking-tight">
              THE NUMBERS <br />
              <span className="italic font-serif text-[#E11D74]">SPEAK.</span>
            </h2>
          </div>

          {/* Interactive View Switcher (Functional buttons) */}
          <div className="flex items-center gap-2 p-1 bg-white/5 border border-white/10">
            <button
              onClick={() => setActiveTab('core')}
              className={`px-4 py-2 text-xs font-semibold tracking-wider uppercase transition-colors duration-200 cursor-pointer whitespace-nowrap ${
                activeTab === 'core'
                  ? 'bg-white text-[#0D0D0D]'
                  : 'text-white/60 hover:text-white'
              }`}
            >
              CORE HIGHLIGHTS
            </button>
            <button
              onClick={() => setActiveTab('all')}
              className={`px-4 py-2 text-xs font-semibold tracking-wider uppercase transition-colors duration-200 cursor-pointer whitespace-nowrap ${
                activeTab === 'all'
                  ? 'bg-white text-[#0D0D0D]'
                  : 'text-white/60 hover:text-white'
              }`}
            >
              FULL CAMPAIGN BREAKDOWN
            </button>
          </div>
        </div>

        {/* Primary Four Core Figures Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-0 border-t border-l border-white/15">
          {PRIMARY_METRICS.map((metric, idx) => (
            <div
              key={metric.label + idx}
              className="p-8 sm:p-10 border-r border-b border-white/15 hover:bg-white/[0.03] transition-colors duration-300 flex flex-col justify-between min-h-[260px] group"
            >
              <div className="flex items-center justify-between text-[11px] font-mono text-white/40 mb-8 pb-3 border-b border-white/5">
                <span>0{idx + 1}</span>
                <span className="group-hover:text-[#E11D74] transition-colors">KPI</span>
              </div>

              <div>
                <div className="font-serif text-5xl sm:text-6xl lg:text-7xl tracking-tight text-white mb-3 font-normal tabular-nums group-hover:text-[#E11D74] transition-colors duration-300">
                  {hasAnimated ? metric.value : '0.0'}
                </div>

                <div className="text-xs sm:text-sm font-semibold tracking-[0.16em] uppercase text-white/90 mb-1">
                  {metric.label}
                </div>

                <p className="text-xs text-white/50 leading-relaxed font-light">
                  {metric.subtext}
                </p>
              </div>
            </div>
          ))}
        </div>

        {/* Additional Figures Expanded View */}
        {(activeTab === 'all' || true) && (
          <div className="mt-16 pt-12 border-t border-white/10">
            <div className="flex items-center justify-between mb-8">
              <span className="text-[11px] font-mono tracking-[0.2em] text-white/50 uppercase">
                DETAILED PORTFOLIO AGGREGATE
              </span>
              <span className="text-[11px] font-mono text-[#E11D74]">
                AUTHENTIC CLIENT OUTCOMES
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-0 border-t border-l border-white/15">
              {ADDITIONAL_METRICS.map((metric, idx) => (
                <div
                  key={metric.label + idx}
                  className="p-6 md:p-8 border-r border-b border-white/15 hover:bg-white/[0.03] transition-colors duration-300 flex flex-col justify-between"
                >
                  <div className="text-[10px] font-mono text-white/30 mb-6">
                    MTR / 0{idx + 5}
                  </div>

                  <div>
                    <div className="font-serif text-3xl sm:text-4xl text-white mb-2 tabular-nums font-normal group-hover:text-[#E11D74]">
                      {hasAnimated ? metric.value : '0'}
                    </div>
                    <div className="text-xs font-semibold tracking-wider uppercase text-white/80 mb-1">
                      {metric.label}
                    </div>
                    <p className="text-[11px] text-white/50 leading-snug">
                      {metric.subtext}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Verification Guarantee */}
        <div className="mt-16 pt-6 border-t border-white/10 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 text-xs text-white/40 font-mono">
          <div>
            SOURCE: META BUSINESS SUITE &amp; LINKEDIN CAMPAIGN MANAGER AUDITED METRICS.
          </div>
          <div>
            ESTABLISHED BY YC AGENCY
          </div>
        </div>
      </div>
    </section>
  );
};
