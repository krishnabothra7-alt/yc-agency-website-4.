import React, { useState, useEffect } from 'react';
import { X, ArrowUpRight, Send, CheckCircle2, MessageCircle, Phone, Mail } from 'lucide-react';
import { AGENCY_INFO } from '../data/agencyData.ts';

interface InquiryModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialService?: string;
}

export const InquiryModal: React.FC<InquiryModalProps> = ({
  isOpen,
  onClose,
  initialService,
}) => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    brand: '',
    service: initialService || 'Comprehensive Social Media Growth',
    budget: 'Flexible',
    message: '',
  });

  const [submitted, setSubmitted] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    if (initialService) {
      setFormData((prev) => ({ ...prev, service: initialService }));
    }
  }, [initialService]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && isOpen) {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    setTimeout(() => {
      setSubmitting(false);
      setSubmitted(true);
    }, 500);
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="modal-headline"
      className="fixed inset-0 z-50 overflow-y-auto bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 sm:p-6 animate-in fade-in duration-200"
    >
      <div className="relative bg-[#FAF9F6] border border-[#0D0D0D] w-full max-w-2xl p-6 sm:p-10 shadow-[8px_8px_0px_#0D0D0D] max-h-[90vh] overflow-y-auto">
        {/* Close Button */}
        <button
          onClick={onClose}
          aria-label="Close dialog"
          className="absolute top-6 right-6 p-2 text-[#0D0D0D] hover:text-[#E11D74] transition-colors focus:outline-none"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Modal Header */}
        <div className="mb-8 pb-6 border-b border-[#0D0D0D]/10 pr-8">
          <div className="text-[10px] font-mono tracking-[0.25em] text-[#E11D74] font-semibold uppercase mb-2">
            YC · PROJECT INQUIRY
          </div>
          <h3 id="modal-headline" className="font-serif text-3xl sm:text-4xl text-[#0D0D0D] tracking-tight font-normal">
            LET&apos;S WORK TOGETHER.
          </h3>
          <p className="text-xs sm:text-sm text-[#0D0D0D]/70 mt-2">
            Tell us about your brand. Founders Yashvee and Chetna review every submission directly.
          </p>
        </div>

        {submitted ? (
          <div className="py-10 flex flex-col items-center text-center space-y-4">
            <CheckCircle2 className="w-12 h-12 text-[#E11D74]" />
            <h4 className="font-serif text-2xl text-[#0D0D0D]">Brief Received</h4>
            <p className="text-sm text-[#0D0D0D]/70 max-w-sm">
              We have recorded your details. We will reach back out within 24 business hours.
            </p>

            <div className="pt-4 flex flex-wrap gap-4 justify-center">
              <a
                href={`https://wa.me/919581314751?text=Hello%20Chetna,%20I%20just%20submitted%20a%20project%20inquiry%20for%20${encodeURIComponent(
                  formData.brand || 'my brand'
                )}.`}
                target="_blank"
                rel="noreferrer"
                className="inline-flex items-center gap-2 px-4 py-2.5 bg-[#25D366] text-white text-xs font-semibold uppercase tracking-wider"
              >
                <MessageCircle className="w-4 h-4" />
                <span>Message on WhatsApp</span>
              </a>

              <button
                onClick={onClose}
                className="px-5 py-2.5 text-xs font-semibold uppercase tracking-wider border border-[#0D0D0D] text-[#0D0D0D]"
              >
                Close
              </button>
            </div>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-5">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-mono uppercase text-[#0D0D0D]/60 mb-1.5">
                  Name *
                </label>
                <input
                  type="text"
                  required
                  placeholder="Your full name"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  className="w-full px-3.5 py-2.5 bg-white border border-[#0D0D0D]/15 text-sm focus:outline-none focus:border-[#E11D74]"
                />
              </div>

              <div>
                <label className="block text-xs font-mono uppercase text-[#0D0D0D]/60 mb-1.5">
                  Email *
                </label>
                <input
                  type="email"
                  required
                  placeholder="name@company.com"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  className="w-full px-3.5 py-2.5 bg-white border border-[#0D0D0D]/15 text-sm focus:outline-none focus:border-[#E11D74]"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-mono uppercase text-[#0D0D0D]/60 mb-1.5">
                  Brand or Company
                </label>
                <input
                  type="text"
                  placeholder="Company name"
                  value={formData.brand}
                  onChange={(e) => setFormData({ ...formData, brand: e.target.value })}
                  className="w-full px-3.5 py-2.5 bg-white border border-[#0D0D0D]/15 text-sm focus:outline-none focus:border-[#E11D74]"
                />
              </div>

              <div>
                <label className="block text-xs font-mono uppercase text-[#0D0D0D]/60 mb-1.5">
                  Phone / WhatsApp
                </label>
                <input
                  type="tel"
                  placeholder="+91..."
                  value={formData.phone}
                  onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                  className="w-full px-3.5 py-2.5 bg-white border border-[#0D0D0D]/15 text-sm focus:outline-none focus:border-[#E11D74]"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-mono uppercase text-[#0D0D0D]/60 mb-1.5">
                Primary Area of Interest
              </label>
              <input
                type="text"
                value={formData.service}
                onChange={(e) => setFormData({ ...formData, service: e.target.value })}
                className="w-full px-3.5 py-2.5 bg-white border border-[#0D0D0D]/15 text-sm focus:outline-none focus:border-[#E11D74]"
              />
            </div>

            <div>
              <label className="block text-xs font-mono uppercase text-[#0D0D0D]/60 mb-1.5">
                Tell Us About Your Goals
              </label>
              <textarea
                rows={3}
                placeholder="What challenges or growth milestones are you targeting on Meta and LinkedIn?"
                value={formData.message}
                onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                className="w-full px-3.5 py-2.5 bg-white border border-[#0D0D0D]/15 text-sm focus:outline-none focus:border-[#E11D74] resize-none"
              ></textarea>
            </div>

            <button
              type="submit"
              disabled={submitting}
              className="w-full py-3.5 px-6 text-xs font-semibold uppercase tracking-[0.16em] text-white bg-[#0D0D0D] hover:bg-[#E11D74] transition-colors cursor-pointer"
            >
              {submitting ? 'SENDING BRIEF...' : 'SUBMIT INQUIRY'}
            </button>
          </form>
        )}

        {/* Direct Connect Quick Links */}
        <div className="mt-6 pt-5 border-t border-[#0D0D0D]/10 flex flex-wrap items-center justify-between gap-4 text-xs font-mono text-[#0D0D0D]/60">
          <a
            href="mailto:ycagencyinfo@gmail.com"
            className="hover:text-[#E11D74] flex items-center gap-1.5"
          >
            <Mail className="w-3.5 h-3.5" />
            <span>ycagencyinfo@gmail.com</span>
          </a>

          <div className="flex items-center gap-3">
            <a href="tel:+919581314751" className="hover:text-[#E11D74]">
              Chetna: +91 95813 14751
            </a>
            <span>·</span>
            <a href="tel:+919989798548" className="hover:text-[#E11D74]">
              Yashvee: +91 99897 98548
            </a>
          </div>
        </div>
      </div>
    </div>
  );
};
