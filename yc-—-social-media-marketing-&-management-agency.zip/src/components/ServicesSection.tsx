import React, { useState } from 'react';
import { ArrowUpRight, Plus, Minus, Check } from 'lucide-react';
import { SERVICES, ServiceItem } from '../data/agencyData.ts';

interface ServicesSectionProps {
  onSelectService: (serviceName: string) => void;
}

export const ServicesSection: React.FC<ServicesSectionProps> = ({ onSelectService }) => {
  const [expandedId, setExpandedId] = useState<string | null>('01');

  const toggleExpand = (id: string) => {
    setExpandedId((prev) => (prev === id ? null : id));
  };

  return (
    <section id="services" className="py-24 md:py-32 border-b border-[#0D0D0D]/10 bg-[#FAF9F6]">
      <div className="max-w-7xl mx-auto px-6 md:px-10">
        {/* Section Eyebrow */}
        <div className="flex items-center gap-3 mb-6">
          <span className="text-[11px] font-mono tracking-[0.25em] text-[#E11D74] font-semibold uppercase">
            WHAT WE DO
          </span>
          <span className="w-12 h-[1px] bg-[#E11D74]/40"></span>
          <span className="text-[11px] font-mono tracking-widest text-[#0D0D0D]/40 uppercase hidden sm:inline">
            CAPABILITIES &amp; EXECUTION
          </span>
        </div>

        {/* Headline & Supporting Text */}
        <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-8 mb-16 md:mb-20">
          <h2 className="font-serif text-4xl sm:text-5xl md:text-6xl lg:text-7xl leading-[1.02] text-[#0D0D0D] font-normal tracking-tight text-balance max-w-3xl">
            EVERYTHING YOUR BRAND <br />
            <span className="italic">NEEDS TO GROW ONLINE.</span>
          </h2>

          <p className="text-base sm:text-lg text-[#0D0D0D]/70 max-w-md font-normal leading-relaxed text-pretty">
            Everything we do for your Instagram, Facebook, WhatsApp and LinkedIn presence.
          </p>
        </div>

        {/* Editorial Service Rows (NOT rounded boxes!) */}
        <div className="border-t border-[#0D0D0D]/15 divide-y divide-[#0D0D0D]/10">
          {SERVICES.map((service: ServiceItem) => {
            const isExpanded = expandedId === service.id;

            return (
              <div
                key={service.id}
                onClick={() => toggleExpand(service.id)}
                className={`group relative py-7 md:py-9 transition-all duration-300 cursor-pointer ${
                  isExpanded ? 'bg-white/80 pl-4 sm:pl-6 -mx-4 sm:-mx-6 pr-4 sm:pr-6' : 'hover:pl-3'
                }`}
              >
                {/* Pink indicator hairline on hover/expanded */}
                <div
                  className={`absolute left-0 top-0 bottom-0 w-[3px] bg-[#E11D74] transition-all duration-300 ${
                    isExpanded ? 'opacity-100' : 'opacity-0 group-hover:opacity-100'
                  }`}
                />

                <div className="grid grid-cols-1 md:grid-cols-12 gap-4 md:gap-8 items-start">
                  {/* Number & Platforms */}
                  <div className="md:col-span-2 flex items-baseline justify-between md:flex-col gap-1">
                    <span
                      className={`font-mono text-sm md:text-base font-semibold tracking-wider transition-colors duration-200 ${
                        isExpanded ? 'text-[#E11D74]' : 'text-[#0D0D0D]/40 group-hover:text-[#E11D74]'
                      }`}
                    >
                      {service.number}
                    </span>

                    <div className="flex flex-wrap gap-1.5 text-[10px] font-mono tracking-wider uppercase text-[#0D0D0D]/50">
                      {service.platforms.map((p, pIdx) => (
                        <span key={p}>
                          {p}
                          {pIdx < service.platforms.length - 1 ? ' ·' : ''}
                        </span>
                      ))}
                    </div>
                  </div>

                  {/* Title */}
                  <div className="md:col-span-4">
                    <h3
                      className={`font-serif text-2xl sm:text-3xl md:text-3xl font-normal tracking-tight transition-all duration-200 ${
                        isExpanded
                          ? 'text-[#0D0D0D] font-medium'
                          : 'text-[#0D0D0D] group-hover:text-[#0D0D0D] group-hover:translate-x-1'
                      }`}
                    >
                      {service.title}
                    </h3>
                  </div>

                  {/* Description & Deliverables */}
                  <div className="md:col-span-5 flex flex-col justify-between">
                    <p className="text-sm sm:text-base text-[#0D0D0D]/75 leading-relaxed font-normal">
                      {service.description}
                    </p>

                    {/* Expanded Deliverables Breakdown */}
                    {isExpanded && service.deliverables && (
                      <div className="mt-5 pt-4 border-t border-[#0D0D0D]/10 animate-in fade-in slide-in-from-top-1 duration-200">
                        <div className="text-[10px] font-mono tracking-[0.2em] text-[#0D0D0D]/50 uppercase mb-3">
                          KEY DELIVERABLES
                        </div>
                        <ul className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs text-[#0D0D0D]/80">
                          {service.deliverables.map((item) => (
                            <li key={item} className="flex items-start gap-2">
                              <span className="w-1.5 h-1.5 rounded-full bg-[#E11D74] mt-1.5 shrink-0" />
                              <span>{item}</span>
                            </li>
                          ))}
                        </ul>

                        <div className="mt-4 pt-3 flex items-center justify-between">
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              onSelectService(service.title);
                            }}
                            className="inline-flex items-center gap-1.5 text-xs font-semibold tracking-wider text-[#E11D74] hover:text-[#0D0D0D] uppercase"
                          >
                            <span>INQUIRE ABOUT {service.title}</span>
                            <ArrowUpRight className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    )}
                  </div>

                  {/* Toggle Indicator Button */}
                  <div className="md:col-span-1 flex justify-end items-center pt-1">
                    <span
                      className={`w-8 h-8 rounded-full border border-[#0D0D0D]/15 flex items-center justify-center transition-colors duration-200 ${
                        isExpanded
                          ? 'bg-[#0D0D0D] text-white border-[#0D0D0D]'
                          : 'text-[#0D0D0D]/60 group-hover:border-[#E11D74] group-hover:text-[#E11D74]'
                      }`}
                    >
                      {isExpanded ? <Minus className="w-3.5 h-3.5" /> : <Plus className="w-3.5 h-3.5" />}
                    </span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* Editorial Footnote */}
        <div className="mt-16 pt-8 border-t border-[#0D0D0D]/15 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 text-xs text-[#0D0D0D]/60">
          <div>
            Comprehensive Meta (Instagram &amp; Facebook) + WhatsApp &amp; LinkedIn Full-Cycle Delivery.
          </div>
          <div className="font-mono text-[11px] tracking-wider text-[#0D0D0D]/40 uppercase">
            10 CORE CAPABILITIES
          </div>
        </div>
      </div>
    </section>
  );
};
