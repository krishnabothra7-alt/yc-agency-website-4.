import React, { useState } from 'react';
import { ArrowUpRight } from 'lucide-react';
import { CLIENTS, ClientItem } from '../data/agencyData.ts';

interface WorkClientsSectionProps {
  onOpenContact: (clientContext?: string) => void;
}

export const WorkClientsSection: React.FC<WorkClientsSectionProps> = ({ onOpenContact }) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('ALL');

  const categories = [
    'ALL',
    'Fashion & Apparel',
    'Jewellery & Luxury',
    'Food & Hospitality',
    'Lifestyle & Retail',
    'Education & Enterprise',
  ];

  const filteredClients =
    selectedCategory === 'ALL'
      ? CLIENTS
      : CLIENTS.filter((c) => c.category === selectedCategory);

  return (
    <section id="work" className="py-24 md:py-32 border-b border-[#0D0D0D]/10 bg-[#FAF9F6]">
      <div className="max-w-7xl mx-auto px-6 md:px-10">
        {/* Section Label */}
        <div className="flex items-center gap-3 mb-6">
          <span className="text-[11px] font-mono tracking-[0.25em] text-[#E11D74] font-semibold uppercase">
            OUR WORK
          </span>
          <span className="w-12 h-[1px] bg-[#E11D74]/40" />
          <span className="text-[11px] font-mono tracking-widest text-[#0D0D0D]/40 uppercase hidden sm:inline">
            CLIENT ROSTER
          </span>
        </div>

        {/* Headline & Supporting Copy */}
        <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-8 mb-14 md:mb-16">
          <div>
            <h2 className="font-serif text-4xl sm:text-5xl md:text-6xl lg:text-7xl leading-[1.02] text-[#0D0D0D] font-normal tracking-tight text-balance">
              BRANDS WE&apos;VE <br />
              <span className="italic">HELPED GROW.</span>
            </h2>
          </div>

          <p className="text-base sm:text-lg text-[#0D0D0D]/70 max-w-md font-normal leading-relaxed text-pretty">
            A selection of the businesses we&apos;ve worked with and assisted with their marketing and advertising.
          </p>
        </div>

        {/* Interactive Industry Filter Tabs (Functional segmented buttons) */}
        <div className="flex flex-wrap items-center gap-2 mb-12 pb-6 border-b border-[#0D0D0D]/10">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-3.5 py-1.5 text-xs font-semibold tracking-wider uppercase transition-colors duration-200 cursor-pointer ${
                selectedCategory === cat
                  ? 'bg-[#0D0D0D] text-white'
                  : 'bg-white/60 text-[#0D0D0D]/70 hover:text-[#0D0D0D] hover:bg-white border border-[#0D0D0D]/10'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Elegant Editorial Typographic Client Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 border-t border-l border-[#0D0D0D]/15">
          {filteredClients.map((client: ClientItem, idx) => (
            <div
              key={client.name}
              onClick={() => onOpenContact(`Inquiry regarding similar growth strategy to ${client.name}`)}
              className="group relative p-8 border-r border-b border-[#0D0D0D]/15 bg-white/40 hover:bg-white transition-all duration-300 cursor-pointer flex flex-col justify-between min-h-[170px]"
            >
              {/* Top Row: Index & Category */}
              <div className="flex items-center justify-between text-[10px] font-mono tracking-wider text-[#0D0D0D]/40 uppercase mb-4">
                <span>{String(idx + 1).padStart(2, '0')}</span>
                <span className="text-[#0D0D0D]/50 group-hover:text-[#E11D74] transition-colors">
                  {client.category}
                </span>
              </div>

              {/* Client Name in Crisp Editorial Typography */}
              <div className="py-2">
                <h3 className="font-serif text-2xl sm:text-3xl text-[#0D0D0D] tracking-tight font-normal transition-all duration-200 group-hover:text-[#E11D74] group-hover:translate-x-1">
                  {client.name}
                </h3>
              </div>

              {/* Bottom Subtle Row */}
              <div className="flex items-center justify-between pt-4 border-t border-[#0D0D0D]/5 text-[11px] font-mono text-[#0D0D0D]/40">
                <span className="group-hover:text-[#0D0D0D] transition-colors">
                  META &amp; ADS
                </span>
                <ArrowUpRight className="w-3.5 h-3.5 text-transparent group-hover:text-[#E11D74] transition-colors" />
              </div>
            </div>
          ))}
        </div>

        {/* Footnote */}
        <div className="mt-12 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 text-xs text-[#0D0D0D]/60 font-mono">
          <div>
            22+ FEATURED BRANDS IN HIGH-GROWTH RETAIL, FASHION, FOOD &amp; ENTERPRISE.
          </div>
          <button
            onClick={() => onOpenContact()}
            className="text-[#E11D74] font-semibold hover:underline flex items-center gap-1 cursor-pointer"
          >
            <span>JOIN OUR CLIENT ROSTER</span>
            <ArrowUpRight className="w-3 h-3" />
          </button>
        </div>
      </div>
    </section>
  );
};
