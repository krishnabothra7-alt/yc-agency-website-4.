import React from 'react';
import { ArrowUpRight, ArrowDown, Sparkles, TrendingUp, Compass, Check } from 'lucide-react';
import { AGENCY_INFO } from '../data/agencyData.ts';

interface HeroProps {
  onOpenContact: () => void;
}

export const Hero: React.FC<HeroProps> = ({ onOpenContact }) => {
  const scrollToWork = () => {
    const el = document.getElementById('work');
    if (el) el.scrollIntoView({ behavior: 'smooth' });
  };

  const scrollToServices = () => {
    const el = document.getElementById('services');
    if (el) el.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <section
      id="home"
      className="relative min-h-[92vh] pt-28 md:pt-36 pb-16 flex flex-col justify-between border-b border-[#0D0D0D]/10 overflow-hidden"
    >
      {/* Editorial structural background lines */}
      <div className="absolute inset-0 pointer-events-none z-0 opacity-40">
        <div className="max-w-7xl mx-auto h-full px-6 md:px-10 grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="border-r border-[#0D0D0D]/5 h-full"></div>
          <div className="border-r border-[#0D0D0D]/5 h-full hidden md:block"></div>
          <div className="border-r border-[#0D0D0D]/5 h-full"></div>
          <div className="border-r border-[#0D0D0D]/5 h-full hidden md:block"></div>
        </div>
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-6 md:px-10 w-full flex-1 flex flex-col justify-center">
        {/* Top Eyebrow Row */}
        <div className="flex flex-wrap items-center justify-between gap-4 mb-8">
          <div className="flex items-center gap-3">
            <span className="w-2 h-2 rounded-full bg-[#E11D74] animate-pulse"></span>
            <span className="text-[11px] md:text-xs font-semibold tracking-[0.25em] text-[#0D0D0D]/70 uppercase">
              BUILDING AUTHORITY IN THE DIGITAL AGE
            </span>
          </div>

          <div className="text-[11px] font-mono tracking-wider text-[#0D0D0D]/50 hidden sm:block">
            EST. META & LINKEDIN SPECIALISTS
          </div>
        </div>

        {/* Asymmetrical Editorial Hero Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-8 items-center">
          {/* Left Column: Massive Editorial Typography & Action */}
          <div className="lg:col-span-7 flex flex-col">
            <h1 className="font-serif text-5xl sm:text-6xl md:text-7xl lg:text-8xl leading-[0.95] text-[#0D0D0D] tracking-tight font-normal text-balance mb-8">
              WE BUILD BRANDS <br />
              <span className="italic font-serif text-[#0D0D0D] relative inline-block">
                PEOPLE REMEMBER
                <span className="text-[#E11D74] font-serif not-italic">.</span>
              </span>
            </h1>

            <p className="text-base sm:text-lg text-[#0D0D0D]/75 max-w-xl font-normal leading-relaxed mb-10 text-pretty">
              Social media strategy, content and performance marketing designed to help brands build authority, reach the right audience and grow.
            </p>

            {/* CTAs */}
            <div className="flex flex-wrap items-center gap-4 sm:gap-5">
              <button
                onClick={onOpenContact}
                className="group relative inline-flex items-center gap-3 px-7 py-4 text-xs font-semibold tracking-[0.16em] uppercase text-white bg-[#0D0D0D] hover:bg-[#E11D74] transition-all duration-300 shadow-sm cursor-pointer whitespace-nowrap focus:outline-none focus-visible:ring-2 focus-visible:ring-[#E11D74]"
              >
                <span>LET&apos;S WORK TOGETHER</span>
                <ArrowUpRight className="w-4 h-4 transition-transform duration-200 group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
              </button>

              <button
                onClick={scrollToWork}
                className="group relative inline-flex items-center gap-3 px-7 py-4 text-xs font-semibold tracking-[0.16em] uppercase text-[#0D0D0D] border border-[#0D0D0D] hover:bg-[#0D0D0D] hover:text-white transition-all duration-300 cursor-pointer whitespace-nowrap focus:outline-none focus-visible:ring-2 focus-visible:ring-[#0D0D0D]"
              >
                <span>VIEW OUR WORK</span>
                <ArrowDown className="w-4 h-4 transition-transform duration-200 group-hover:translate-y-0.5" />
              </button>
            </div>

            {/* Micro Credential / Founders Attribution */}
            <div className="mt-12 pt-6 border-t border-[#0D0D0D]/10 flex flex-wrap items-center gap-x-8 gap-y-2 text-xs text-[#0D0D0D]/60">
              <div className="flex items-center gap-2">
                <span className="text-[#E11D74] font-semibold">01</span>
                <span>Yashvee Baid · Strategy & Growth</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-[#E11D74] font-semibold">02</span>
                <span>Chetna Bothra · Ad Creative & Visuals</span>
              </div>
            </div>
          </div>

          {/* Right Column: Editorial Visual Composition (YC Identity, NO generic stock photo) */}
          <div className="lg:col-span-5 relative">
            <div className="relative mx-auto max-w-md lg:max-w-none">
              {/* Outer Editorial Canvas Frame */}
              <div className="relative bg-[#FAF9F6] border border-[#0D0D0D] p-6 sm:p-8 shadow-[8px_8px_0px_#0D0D0D]">
                {/* Header Tag of Frame */}
                <div className="flex items-center justify-between pb-4 border-b border-[#0D0D0D]/15 mb-6 text-[11px] font-mono tracking-wider text-[#0D0D0D]/60 uppercase">
                  <span>DISPATCH / 2026</span>
                  <span className="text-[#E11D74] font-semibold">IDENTITY & REACH</span>
                </div>

                {/* Monogram Seal & Core Statement */}
                <div className="flex items-start justify-between gap-4 mb-6">
                  <div>
                    <div className="font-serif text-4xl sm:text-5xl tracking-tight text-[#0D0D0D] leading-none mb-1">
                      YC<span className="text-[#E11D74]">.</span>
                    </div>
                    <div className="text-[11px] font-semibold tracking-[0.2em] uppercase text-[#0D0D0D]/70">
                      SOCIAL MEDIA AGENCY
                    </div>
                  </div>

                  {/* Stamp Graphic with subtle rotation */}
                  <div className="w-16 h-16 rounded-full border border-dashed border-[#0D0D0D]/40 flex items-center justify-center p-2 text-center text-[9px] font-mono leading-tight text-[#0D0D0D]/80">
                    <span className="scale-90">META &amp; LINKEDIN</span>
                  </div>
                </div>

                {/* Editorial Visual Composition Blocks */}
                <div className="space-y-3">
                  {/* Visual Row 1: Brand Authority Card */}
                  <div className="p-4 bg-white border border-[#0D0D0D]/10 hover:border-[#E11D74] transition-colors duration-200">
                    <div className="flex items-center justify-between text-xs mb-1.5">
                      <span className="font-semibold tracking-wider text-[11px] uppercase text-[#0D0D0D]">
                        ORGANIC ALGORITHMIC EXPANSION
                      </span>
                      <span className="font-mono text-[11px] text-[#E11D74] font-semibold">99.7%</span>
                    </div>
                    <p className="text-xs text-[#0D0D0D]/70 leading-relaxed">
                      Reach systematically converted from non-followers through calibrated Reels and carousels.
                    </p>
                    <div className="mt-2.5 h-1 w-full bg-[#FAF9F6] overflow-hidden">
                      <div className="h-full bg-[#E11D74] w-[99.7%]"></div>
                    </div>
                  </div>

                  {/* Visual Row 2: Ad Creative & Conversion */}
                  <div className="p-4 bg-[#0D0D0D] text-white">
                    <div className="flex items-center justify-between text-xs mb-1.5">
                      <span className="font-semibold tracking-wider text-[11px] uppercase text-white/90">
                        PERFORMANCE AD ARCHITECTURE
                      </span>
                      <span className="font-mono text-[11px] text-[#E11D74] font-semibold">620+ CAMPAIGNS</span>
                    </div>
                    <p className="text-xs text-white/70 leading-relaxed">
                      Creative testing frameworks engineered for maximum ROAS and qualified inquiries.
                    </p>
                  </div>

                  {/* Visual Row 3: Founders Lockup */}
                  <div className="p-3.5 bg-white border border-[#0D0D0D]/10 flex items-center justify-between text-xs">
                    <div>
                      <div className="font-serif text-base text-[#0D0D0D]">Yashvee Baid &amp; Chetna Bothra</div>
                      <div className="text-[10px] text-[#0D0D0D]/50 tracking-wider uppercase font-mono">Founders &amp; Leads</div>
                    </div>
                    <button
                      onClick={scrollToServices}
                      className="text-[11px] font-semibold text-[#E11D74] hover:underline flex items-center gap-1 cursor-pointer"
                    >
                      EXPLORE <ArrowUpRight className="w-3 h-3" />
                    </button>
                  </div>
                </div>

                {/* Footer Stamp */}
                <div className="mt-5 pt-3 border-t border-[#0D0D0D]/10 flex items-center justify-between text-[10px] font-mono text-[#0D0D0D]/50 uppercase">
                  <span>SPECIALIZED MANAGEMENT</span>
                  <span className="text-[#0D0D0D] font-semibold">VERIFIED GROWTH</span>
                </div>
              </div>

              {/* Offset Decorative Accent Badge */}
              <div className="hidden sm:flex absolute -bottom-5 -right-5 bg-[#E11D74] text-white px-4 py-2.5 shadow-md items-center gap-2 text-xs font-semibold tracking-widest uppercase">
                <Sparkles className="w-3.5 h-3.5" />
                <span>52.8M+ VIEWS DELIVERED</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Platforms Strip across the bottom of the Hero */}
      <div className="relative z-10 mt-16 pt-8 border-t border-[#0D0D0D]/10 max-w-7xl mx-auto px-6 md:px-10 w-full">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="text-[11px] font-mono tracking-[0.2em] text-[#0D0D0D]/50 uppercase">
            TARGET PLATFORMS
          </div>

          <div className="flex flex-wrap items-center gap-x-6 gap-y-3 text-sm md:text-base font-medium tracking-tight text-[#0D0D0D]">
            {AGENCY_INFO.platforms.map((platform, idx) => (
              <React.Fragment key={platform.name}>
                <span className="hover:text-[#E11D74] transition-colors cursor-default">
                  {platform.name}
                </span>
                {idx < AGENCY_INFO.platforms.length - 1 && (
                  <span className="text-[#0D0D0D]/20 select-none" aria-hidden="true">
                    ·
                  </span>
                )}
              </React.Fragment>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};
